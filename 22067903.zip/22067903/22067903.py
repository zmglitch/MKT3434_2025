import sys
import numpy as np
import pandas as pd
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QComboBox, QTextEdit, QLabel, QMessageBox, 
    QTabWidget, QGridLayout, QLineEdit, QCheckBox, QFileDialog, QGroupBox
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

#Scikit-learn imports
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.neural_network import MLPRegressor, MLPClassifier
from sklearn.svm import SVR, SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import mean_squared_error, mean_absolute_error, accuracy_score, log_loss

class ZMLGui(QMainWindow):
    def __init__(self):
        super().__init__()
        self.dataset = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.model = None
        self.initUI()

    def initUI(self):
        #my color palette
        PASTEL_COLORS = {
            'background': '#F0F4F8',  # Light blue
            'primary': '#E6E6FA',     # Lavender
            'secondary': '#B0E0E6',   # Powder blue
            'accent': '#98FB98',      # Pale green <3
            'text': '#2C3E50',        # Dark blue
            'button': '#DDA0DD',      # Plum
            'button_text': '#FFFFFF'  # White
        }

        self.setWindowTitle("Z-ML Studio")
        self.setGeometry(100, 100, 1200, 800)

        #Main widget ve layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)

        #Tab widget creation
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)

        #Data preparation tab
        data_prep_tab = QWidget()
        data_prep_layout = QVBoxLayout()
        data_prep_tab.setLayout(data_prep_layout)

        #Dataset loading group
        dataset_group = QGroupBox("Dataset Management")
        dataset_layout = QVBoxLayout()
        
        #Imputation Method : Data imputation is a method for retaining the majority of the dataset's data 
        # and information by substituting missing data with a different value

        imputation_layout = QHBoxLayout()
        imputation_label = QLabel("Missing Data Handling:")
        self.imputation_combo = QComboBox()
        self.imputation_combo.addItems([
            "Mean Imputation", 
            "Median Imputation", 
            "Most Frequent", 
            "Constant (0)", 
            "Forward Fill", 
            "Backward Fill"
        ])
        imputation_layout.addWidget(imputation_label)
        imputation_layout.addWidget(self.imputation_combo)
        dataset_layout.addLayout(imputation_layout)

        #Load dataset buton
        load_dataset_btn = QPushButton("Load Dataset")
        load_dataset_btn.clicked.connect(self.load_dataset)
        dataset_layout.addWidget(load_dataset_btn)

        dataset_group.setLayout(dataset_layout)
        data_prep_layout.addWidget(dataset_group)

        #Regression group
        regression_group = QGroupBox("Regression Models")
        regression_layout = QVBoxLayout()

        #Regression model selection
        reg_model_layout = QHBoxLayout()
        reg_model_label = QLabel("Regression Model:")
        self.reg_model_combo = QComboBox()
        self.reg_model_combo.addItems([
            "Linear Regression", 
            "Decision Tree Regression", 
            "Neural Network Regression", 
            "Support Vector Regression"
        ])
        reg_model_layout.addWidget(reg_model_label)
        reg_model_layout.addWidget(self.reg_model_combo)
        regression_layout.addLayout(reg_model_layout)

        #Loss function selection
        loss_layout = QHBoxLayout()
        loss_label = QLabel("Loss Function:")
        self.reg_loss_combo = QComboBox()
        self.reg_loss_combo.addItems([
            "Mean Squared Error (MSE)", 
            "Mean Absolute Error (MAE)", 
            "Huber Loss"
        ])
        loss_layout.addWidget(loss_label)
        loss_layout.addWidget(self.reg_loss_combo)
        regression_layout.addLayout(loss_layout)

        #SVM regression parameters
        svm_reg_layout = QGridLayout()
        kernel_label = QLabel("Kernel:")
        self.svm_kernel_combo = QComboBox()
        self.svm_kernel_combo.addItems(["Linear", "RBF", "Polynomial"])
        
        c_param_label = QLabel("C Parameter:")
        self.c_param_input = QLineEdit("1.0")
        
        epsilon_label = QLabel("Epsilon:")
        self.epsilon_input = QLineEdit("0.1")
        
        svm_reg_layout.addWidget(kernel_label, 0, 0)
        svm_reg_layout.addWidget(self.svm_kernel_combo, 0, 1)
        svm_reg_layout.addWidget(c_param_label, 1, 0)
        svm_reg_layout.addWidget(self.c_param_input, 1, 1)
        svm_reg_layout.addWidget(epsilon_label, 2, 0)
        svm_reg_layout.addWidget(self.epsilon_input, 2, 1)
        
        regression_layout.addLayout(svm_reg_layout)

        #Train regression rodel button
        train_reg_btn = QPushButton("Train Regression Model")
        train_reg_btn.clicked.connect(self.train_regression_model)
        regression_layout.addWidget(train_reg_btn)

        regression_group.setLayout(regression_layout)
        data_prep_layout.addWidget(regression_group)

        #Classification group
        classification_group = QGroupBox("Classification Models")
        classification_layout = QVBoxLayout()

        #For bayesian classification 
        bayesian_layout = QGridLayout()
        bayesian_label = QLabel("Gaussian Naive Bayes:")
        var_smoothing_label = QLabel("Var Smoothing:")
        self.var_smoothing_input = QLineEdit("1e-9")
        
        prior_label = QLabel("Prior Probabilities:")
        self.prior_input = QLineEdit("uniform")
        
        bayesian_layout.addWidget(bayesian_label, 0, 0)
        bayesian_layout.addWidget(var_smoothing_label, 1, 0)
        bayesian_layout.addWidget(self.var_smoothing_input, 1, 1)
        bayesian_layout.addWidget(prior_label, 2, 0)
        bayesian_layout.addWidget(self.prior_input, 2, 1)
        
        classification_layout.addLayout(bayesian_layout)

        classification_group.setLayout(classification_layout)
        data_prep_layout.addWidget(classification_group)

        #Results text part
        results_group = QGroupBox("Results and Logs")
        results_layout = QVBoxLayout()
        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        results_layout.addWidget(self.results_text)
        results_group.setLayout(results_layout)
        data_prep_layout.addWidget(results_group)

        #Add tabs to tab widget
        self.tab_widget.addTab(data_prep_tab, "ML Workflow")

        #Styling 
        self.setStyleSheet("""
            QWidget { 
                background-color: #F0F4F8; 
                color: #2C3E50;
            }
            QGroupBox {
                border: 2px solid #B0E0E6;
                margin-top: 10px;
                font-weight: bold;
                border-radius: 5px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
            QPushButton { 
                background-color: #DDA0DD; 
                color: white; 
                border-radius: 5px; 
                padding: 8px;
            }
            QPushButton:hover { 
                background-color: #B0E0E6; 
            }
            QComboBox, QLineEdit { 
                background-color: #E6E6FA;
                border: 1px solid #B0E0E6;
                border-radius: 3px;
                padding: 5px;
            }
        """)

    def load_dataset(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Dataset", "", "CSV Files (*.csv)")
        if file_name:
            try:
                self.dataset = pd.read_csv(file_name)
                
                #Imputation handling
                imputation_method = self.imputation_combo.currentText()
                if imputation_method == "Mean Imputation":
                    imputer = SimpleImputer(strategy='mean')
                elif imputation_method == "Median Imputation":
                    imputer = SimpleImputer(strategy='median')
                elif imputation_method == "Most Frequent":
                    imputer = SimpleImputer(strategy='most_frequent')
                elif imputation_method == "Constant (0)":
                    imputer = SimpleImputer(strategy='constant', fill_value=0)
                
                #last column is target
                X = self.dataset.iloc[:, :-1]
                y = self.dataset.iloc[:, -1]
                
                #Apply imputation
                X_imputed = imputer.fit_transform(X)
                
                #Split data
                self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
                    X_imputed, y, test_size=0.2, random_state=42
                )
                
                #Scaling
                scaler = StandardScaler()
                self.X_train = scaler.fit_transform(self.X_train)
                self.X_test = scaler.transform(self.X_test)
                
                self.results_text.setText(f"Dataset loaded: {file_name}\n"
                                          f"Total samples: {len(self.dataset)}\n"
                                          f"Training samples: {len(self.X_train)}\n"
                                          f"Test samples: {len(self.X_test)}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Could not load dataset: {str(e)}")

    def train_regression_model(self):
        if self.X_train is None:
            QMessageBox.warning(self, "Warning", "Please load a dataset first!")
            return

        model_name = self.reg_model_combo.currentText()
        loss_function = self.reg_loss_combo.currentText()

        try:
            if model_name == "Linear Regression":
                self.model = LinearRegression()
            elif model_name == "Decision Tree Regression":
                self.model = DecisionTreeRegressor()
            elif model_name == "Neural Network Regression":
                self.model = MLPRegressor(max_iter=1000)
            elif model_name == "Support Vector Regression":
                kernel = self.svm_kernel_combo.currentText().lower()
                C = float(self.c_param_input.text())
                epsilon = float(self.epsilon_input.text())
                self.model = SVR(kernel=kernel, C=C, epsilon=epsilon)

            #Train the model
            self.model.fit(self.X_train, self.y_train)
            
            #Predictions
            y_pred = self.model.predict(self.X_test)
            
            #Calculate loss
            if loss_function == "Mean Squared Error (MSE)":
                loss = mean_squared_error(self.y_test, y_pred)
            elif loss_function == "Mean Absolute Error (MAE)":
                loss = mean_absolute_error(self.y_test, y_pred)
            
            #Update results
            self.results_text.append(f"\nRegression Results:\n"
                                     f"Model: {model_name}\n"
                                     f"Loss Function: {loss_function}\n"
                                     f"Loss Value: {loss:.4f}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Model training failed: {str(e)}")

def main():
    app = QApplication(sys.argv)
    gui = ZMLGui()
    gui.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
